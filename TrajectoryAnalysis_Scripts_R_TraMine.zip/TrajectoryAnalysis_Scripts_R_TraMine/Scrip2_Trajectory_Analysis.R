# ==================================================
# ArtistCareerTrajectory
# Script 02: Trajectory Characteristics
# ==================================================


# ==================================================
# Load libraries
# ==================================================

library(readr)
library(dplyr)


# ==================================================
# Read data
# ==================================================

simulation_x <- read_csv(
  "outputR/Sim1_combined_status.csv"   ######## CHANGE SIMULATION NUMBER HERE Sim1, Sim2, ... etc
)

trajectory_characteristics <- read_csv(
  "outputR/Sim1_trajectory_characteristics_status.csv"     ######## CHANGE SIMULATION NUMBER HERE Sim1, Sim2, ... etc
)


# ==================================================
# Extract final observation of each trajectory
# ==================================================

final_state <- simulation_x %>%
  
  group_by(ArtistID) %>%
  
  slice_max(
    Tick,
    n = 1,
    with_ties = FALSE
  ) %>%
  
  select(
    ArtistID,
    FinalState = State,
    FinalStatus = Status,
    FinalEC = EC,
    FinalSC = SC
  )


# ==================================================
# First exit tick
# ==================================================

exit_tick <- simulation_x %>%
  
  filter(
    Status == "X"
  ) %>%
  
  group_by(ArtistID) %>%
  
  summarise(
    ExitTick = min(Tick),
    .groups = "drop"
  )


# ==================================================
# Join trajectory information
# ==================================================

trajectory_characteristics <- trajectory_characteristics %>%
  
  left_join(
    final_state,
    by = "ArtistID"
  ) %>%
  
  left_join(
    exit_tick,
    by = "ArtistID"
  )


# ==================================================
# Artists never exiting
# ==================================================

trajectory_characteristics <- trajectory_characteristics %>%
  
  mutate(
    
    ExitTick = ifelse(
      is.na(ExitTick),
      199,
      ExitTick
    ),
    
    FinalSurvivor = FinalStatus != "X",
    
    CareerDuration = ExitTick + 1
    
  )

write.csv(
  trajectory_characteristics,
  "outputR/Sim1_trajectory_characteristics_complete.csv",    ##### CHANGE SIMULATION NUMBER HERE Sim1, Sim2, ... etc
  row.names = FALSE
)