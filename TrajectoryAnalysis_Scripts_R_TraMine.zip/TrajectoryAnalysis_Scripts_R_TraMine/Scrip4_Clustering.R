# ==================================================
# ArtistCareerTrajectory
# Script 04: Trajectory Clustering (Simulation x)
# ==================================================


# ==================================================
# Load libraries
# ==================================================

library(readr)
library(dplyr)


# ==================================================
# Read OM distance matrix
# ==================================================

OM_distance <- readRDS(
  "outputR/Sim1_OM_distance.rds"   
)


# ==================================================
# Convert to distance object
# ==================================================

OM_dist <- as.dist(
  OM_distance
)


# ==================================================
# Hierarchical clustering
# ==================================================

trajectory_hclust <- hclust(
  OM_dist,
  method = "ward.D2"
)


# ==================================================
# Plot dendrogram
# ==================================================

plot(
  trajectory_hclust,
  labels = FALSE,
  main = "Simulation 1 - Hierarchical clustering",  
  xlab = "",
  sub = ""
)


# ==================================================
# Compare different numbers of clusters
# ==================================================

cluster_results <- data.frame()

for (k in 2:6) {
  
  cluster_assignment <- cutree(
    trajectory_hclust,
    k = k
  )
  
  cluster_sizes <- table(
    cluster_assignment
  )
  
  temp <- data.frame(
    k = k,
    Cluster = names(cluster_sizes),
    Size = as.numeric(cluster_sizes)
  )
  
  cluster_results <- bind_rows(
    cluster_results,
    temp
  )
  
}


# ==================================================
# Display cluster sizes
# ==================================================

cluster_results <- cluster_results %>%
  arrange(
    k,
    Cluster
  )

print(cluster_results)


# ==================================================
# Select final solution
# ==================================================

cluster_assignment <- cutree(
  trajectory_hclust,
  k = 4
)


# ==================================================
# Create cluster membership table
# ==================================================

cluster_membership <- data.frame(
  
  ArtistID = as.numeric(
    names(cluster_assignment)
  ),
  
  Cluster = as.numeric(
    cluster_assignment
  )
  
)


# ==================================================
# Check cluster sizes
# ==================================================

print(
  table(cluster_membership$Cluster)
)


# ==================================================
# Read trajectory characteristics
# ==================================================

trajectory_characteristics <- read_csv(
  "outputR/Sim1_trajectory_characteristics_complete.csv"   
)


# ==================================================
# Check ArtistID exists
# ==================================================

print(
  names(trajectory_characteristics)
)


# ==================================================
# Join cluster membership
# ==================================================

trajectory_clusters <- trajectory_characteristics %>%
  
  left_join(
    cluster_membership,
    by = "ArtistID"
  )


# ==================================================
# Check join
# ==================================================

head(trajectory_clusters)

summary(trajectory_clusters$Cluster)


# ==================================================
# Cluster summary
# ==================================================

cluster_summary <- trajectory_clusters %>%
  
  group_by(
    Cluster
  ) %>%
  
  summarise(
    
    N = n(),
    
    MeanTransitions = mean(
      Transitions,
      na.rm = TRUE
    ),
    
    SDTransitions = sd(
      Transitions,
      na.rm = TRUE
    ),
    
    MeanTurbulence = mean(
      Turbulence,
      na.rm = TRUE
    ),
    
    SDTurbulence = sd(
      Turbulence,
      na.rm = TRUE
    ),
    
    MeanEntropy = mean(
      Entropy,
      na.rm = TRUE
    ),
    
    SDEntropy = sd(
      Entropy,
      na.rm = TRUE
    ),
    
    MeanExitTick = mean(
      ExitTick,
      na.rm = TRUE
    ),
    
    MeanFinalEC = mean(
      FinalEC,
      na.rm = TRUE
    ),
    
    MeanFinalSC = mean(
      FinalSC,
      na.rm = TRUE
    ),
    
    Survivors = sum(
      FinalSurvivor,
      na.rm = TRUE
    ),
    
    .groups = "drop"
    
  )


# ==================================================
# Display results
# ==================================================

print(cluster_summary)

View(cluster_summary)

View(trajectory_clusters)


# ==================================================
# Save outputs
# ==================================================

write.csv(
  
  trajectory_clusters,
  
  "outputR/Sim1_trajectory_clusters_k4.csv",   
  
  row.names = FALSE
  
)


write.csv(
  
  cluster_summary,
  
  "outputR/Sim1_cluster_summary_k4.csv",   
  
  row.names = FALSE
  
)


cat("\n")
cat("=============================================\n")
cat("Simulation clustering completed.\n")
cat("=============================================\n")
