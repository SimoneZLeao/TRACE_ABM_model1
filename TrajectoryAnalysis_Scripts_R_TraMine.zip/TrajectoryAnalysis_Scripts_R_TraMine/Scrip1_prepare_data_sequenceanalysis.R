# ==================================================
# ArtistCareerTrajectory
# Script 01: Sequence Characteristics
# Create longitudinal sequences and metrics
# ==================================================


# ==================================================
# Load libraries
# ==================================================

library(readr)
library(dplyr)
library(TraMineR)


# ==================================================
# Define data folder
# ==================================================

data_folder <- "dataR"


# ==================================================
# Read simulation CSV files
# ==================================================



simulation_x <- read_csv(
  file.path(data_folder, "trace_sim1.csv")     
)


# ==================================================
# Create Status categories
# ==================================================

simulation_x <- simulation_x %>%
  mutate(
    Status = case_when(
      
      State == "Exited" ~ "X",
      
      EC >= 50000 & State == "Active" ~ "B",
      
      EC < 50000 & EC >= 42000 & State == "Active" ~ "C",
      
      EC < 42000 & EC >= 23200 & State == "Active" ~ "G",
      
      EC < 23200 & EC >= 10000 & State == "Active" ~ "Y",
      
      EC < 10000 & State == "Active" ~ "R",
      
      TRUE ~ NA_character_
    )
  )


# ==================================================
# Check Status classification
# ==================================================

table(simulation_x$Status)

table(
  simulation_x$State,
  simulation_x$Status
)


sum(is.na(simulation_x$Status))


# ==================================================
# Save datasets
# ==================================================

write.csv(
  simulation_x,
  "outputR/Sim1_combined_status.csv",  
  row.names = FALSE
)


# ==================================================
# Prepare chronological order
# ==================================================

simulation_x <- simulation_x %>%
  arrange(
    ArtistID,
    Tick
  )


# ==================================================
# Create one sequence per trajectory
# ==================================================

trajectory_sequences <- simulation_x %>%
  
  group_by(
    ArtistID,
  ) %>%
  
  summarise(
    Sequence = paste(
      Status,
      collapse = ""
    ),
    .groups = "drop"
  )


# ==================================================
# Check sequences
# ==================================================

head(trajectory_sequences)

nrow(trajectory_sequences)


table(
  nchar(trajectory_sequences$Sequence)
)


# ==================================================
# Create TraMineR sequence object
# ==================================================

sequence_matrix <- do.call(
  rbind,
  strsplit(
    trajectory_sequences$Sequence,
    ""
  )
)


rownames(sequence_matrix) <- trajectory_sequences$ArtistID


career_sequences <- seqdef(
  sequence_matrix,
  alphabet = c(
    "B",
    "C",
    "G",
    "Y",
    "R",
    "X"
  ),
  labels = c(
    "High",
    "Sustainable",
    "Average",
    "Precarious",
    "Critical",
    "Exited"
  )
)

# ==================================================
# Calculate sequence metrics
# ==================================================

transitions <- seqtransn(
  career_sequences
)


turbulence <- seqST(
  career_sequences
)


entropy <- seqient(
  career_sequences
)


# ==================================================
# Create trajectory characteristics table
# ==================================================

trajectory_characteristics <- trajectory_sequences %>%
  
  mutate(
    Transitions = transitions,
    Turbulence = turbulence,
    Entropy = entropy
  )


# ==================================================
# Check final table
# ==================================================

head(trajectory_characteristics)

summary(trajectory_characteristics)


# ==================================================
# Save trajectory characteristics
# ==================================================

write.csv(
  trajectory_characteristics,
  "outputR/Sim1_trajectory_characteristics_status.csv",     
  row.names = FALSE
)