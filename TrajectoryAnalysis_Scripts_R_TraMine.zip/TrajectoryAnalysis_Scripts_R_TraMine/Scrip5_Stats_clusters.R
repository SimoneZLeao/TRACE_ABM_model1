# ==================================================
# ArtistCareerTrajectory
# Script 05: Active Career Capital Profiles
# Simulation 1
# ==================================================


# ==================================================
# Load libraries
# ==================================================

library(readr)
library(dplyr)


# ==================================================
# Read original simulation data
# ==================================================

simulation_x <- read_csv(
  "dataR/trace_sim1.csv",       
  show_col_types = FALSE
)


# ==================================================
# Read clustering results
# ==================================================

cluster_results <- read_csv(
  "outputR/Sim1_trajectory_clusters_k4.csv",     
  show_col_types = FALSE
)


# ==================================================
# Calculate artist-level statistics
# ==================================================

artist_profiles <- simulation_x %>%
  
  group_by(
    ArtistID
  ) %>%
  
  summarise(
    
    # --------------------------------
    # Active career duration
    # --------------------------------
    
    Active_Ticks = sum(
      State == "Active"
    ),
    
    
    # --------------------------------
    # Final accumulated SC
    # during active career
    # --------------------------------
    
    Final_Active_SC = SC[State == "Active"][
      which.max(Tick[State == "Active"])
    ],
    
    
    # --------------------------------
    # Mean EC during active career
    # EC fluctuates, so calculate
    # arithmetic mean only while active
    # --------------------------------
    
    Mean_Active_EC = mean(
      EC[State == "Active"],
      na.rm = TRUE
    ),
    
    
    # --------------------------------
    # SC accumulation rate
    # SC is cumulative, so final SC
    # divided by active duration
    # --------------------------------
    
    Mean_Active_SC = Final_Active_SC / Active_Ticks,
    
    
    # --------------------------------
    # Mean capital across complete record
    # --------------------------------
    
    Mean_EC = mean(
      EC,
      na.rm = TRUE
    ),
    
    Mean_SC = mean(
      SC,
      na.rm = TRUE
    ),
    
    
    # --------------------------------
    # Events received
    # --------------------------------
    
    Recognition_events = sum(
      RecognitionEvent,
      na.rm = TRUE
    ),
    
    Economic_events = sum(
      EconomicEvent,
      na.rm = TRUE
    ),
    
    
    # --------------------------------
    # Capital gains
    # --------------------------------
    
    Total_SC_Gains = sum(
      SCGain,
      na.rm = TRUE
    ),
    
    Total_EC_Gains = sum(
      ECGain,
      na.rm = TRUE
    ),
    
    
    # --------------------------------
    # Investment
    # active period only
    # --------------------------------
    
    Mean_Investment_Disposition = mean(
      InvestmentDisposition,
      na.rm = TRUE
    ),
    
    
    Total_Investment = sum(
      Investment[State == "Active"],
      na.rm = TRUE
    ),
    
    
    Mean_Investment = Total_Investment / Active_Ticks,
    
    
    .groups = "drop"
    
  )


# ==================================================
# Join statistics with clusters
# ==================================================

Sim1_cluster_active_profiles <- cluster_results %>%     
  
  left_join(
    artist_profiles,
    by = "ArtistID"
  )


# ==================================================
# Check artist-level table
# ==================================================

head(
  Sim1_cluster_active_profiles        
)


# ==================================================
# Save artist-level table
# ==================================================

write.csv(
  Sim1_cluster_active_profiles,                          
  "outputR/Sim1_cluster_active_profiles.csv",            
  row.names = FALSE
)


# ==================================================
# Create cluster summary
# ==================================================

Sim1_cluster_active_summary <- Sim1_cluster_active_profiles %>%     
  
  group_by(
    Cluster
  ) %>%
  
  summarise(
    
    Artists = n(),
    
    Mean_Active_EC = mean(
      Mean_Active_EC,
      na.rm = TRUE
    ),
    
    Mean_Active_SC = mean(
      Mean_Active_SC,
      na.rm = TRUE
    ),
    
    Mean_EC = mean(
      Mean_EC,
      na.rm = TRUE
    ),
    
    Mean_SC = mean(
      Mean_SC,
      na.rm = TRUE
    ),
    
    Mean_Recognition_events = mean(
      Recognition_events,
      na.rm = TRUE
    ),
    
    Mean_Economic_events = mean(
      Economic_events,
      na.rm = TRUE
    ),
    
    Mean_SC_Gains = mean(
      Total_SC_Gains,
      na.rm = TRUE
    ),
    
    Mean_EC_Gains = mean(
      Total_EC_Gains,
      na.rm = TRUE
    ),
    
    Mean_Total_Investment = mean(
      Total_Investment,
      na.rm = TRUE
    ),
    
    Mean_Investment = mean(
      Mean_Investment,
      na.rm = TRUE
    ),
    
    Mean_Investment_Disposition = mean(
      Mean_Investment_Disposition,
      na.rm = TRUE
    ),
    
    Mean_Active_Ticks = mean(
      Active_Ticks,
      na.rm = TRUE
    ),
    
    .groups = "drop"
    
  )


# ==================================================
# Display cluster summary
# ==================================================

#print(
#  Sim1_cluster_active_summary              
#)


#View(
#  Sim1_cluster_active_summary              
#)


# ==================================================
# Save cluster summary
# ==================================================

write.csv(
  Sim1_cluster_active_summary,                          
  "outputR/Sim1_cluster_active_summary.csv",            
  row.names = FALSE
)


cat("Active career profiles completed\n")