# ==================================================
# ArtistCareerTrajectory
# Script 03: Optimal Matching (Simulation x)
# ==================================================


# ==================================================
# Load libraries
# ==================================================

library(readr)
library(dplyr)
library(TraMineR)


# ==================================================
# Read simulation X
# ==================================================

simulation_x <- read_csv(
  "outputR/Sim1_combined_status.csv",    
  show_col_types = FALSE
)


# ==================================================
# Check data
# ==================================================

cat("\nRows:", nrow(simulation_x), "\n")
cat("Artists:", length(unique(simulation_x$ArtistID)), "\n")
cat("Ticks:", length(unique(simulation_x$Tick)), "\n")


# ==================================================
# Arrange chronologically
# ==================================================

simulation_x <- simulation_x %>%
  arrange(
    ArtistID,
    Tick
  )


# ==================================================
# Create one sequence per artist
# ==================================================

trajectory_sequences <- simulation_x %>%
  group_by(ArtistID) %>%
  summarise(
    Sequence = paste(Status, collapse = ""),
    .groups = "drop"
  )


# ==================================================
# Check sequence lengths
# ==================================================

print(table(nchar(trajectory_sequences$Sequence)))

if(any(nchar(trajectory_sequences$Sequence) != 200)){
  stop("Some trajectories are not 200 ticks long.")
}


# ==================================================
# Convert sequences to matrix
# ==================================================

sequence_matrix <- do.call(
  rbind,
  strsplit(
    trajectory_sequences$Sequence,
    ""
  )
)


# ==================================================
# Assign Artist IDs
# ==================================================

rownames(sequence_matrix) <- trajectory_sequences$ArtistID


# ==================================================
# Create TraMineR sequence object
# ==================================================

career_sequences <- seqdef(
  sequence_matrix,
  alphabet = c("B","C","G","Y","R","X"),
  labels = c(
    "High",
    "Sustainable",
    "Average",
    "Precarious",
    "Critical",
    "Exited"
  )
)


# ==================================================
# Save sequence object
# ==================================================

saveRDS(
  career_sequences,
  "outputR/Sim1_career_sequences.rds"
)


# ==================================================
# Compute substitution-cost matrix
# ==================================================

cat("\nComputing substitution-cost matrix...\n")

substitution_costs <- seqsubm(
  career_sequences,
  method = "TRATE"
)


# ==================================================
# Compute Optimal Matching distances
# ==================================================

cat("Computing Optimal Matching distances...\n")

OM_distance <- seqdist(
  career_sequences,
  method = "OM",
  sm = substitution_costs,
  indel = 1
)


cat("Optimal Matching completed.\n")


# ==================================================
# Check distance matrix
# ==================================================

print(dim(OM_distance))

print(summary(as.vector(OM_distance)))


# ==================================================
# Save distance matrix
# ==================================================

saveRDS(
  OM_distance,
  "outputR/Sim1_OM_distance.rds"   
)

cat("\n")
cat("============================================\n")
cat("Simulation Optimal Matching completed.\n")
cat("============================================\n")